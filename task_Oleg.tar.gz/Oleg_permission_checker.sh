TARGET_DIR="/opt/101025-ptm"

echo "Проверяю файлы в $TARGET_DIR..."


if [ ! -d "$TARGET_DIR" ]; then
    echo "Ошибка: директория $TARGET_DIR не найдена."
    exit 1
fi

for file in "$TARGET_DIR"/*; do
    
    if [[ "$file" == *.sh ]]; then
        echo "Найден скрипт: $file — добавляю права на исполнение."
        chmod +x "$file"
    fi
done

echo "Готово!"
